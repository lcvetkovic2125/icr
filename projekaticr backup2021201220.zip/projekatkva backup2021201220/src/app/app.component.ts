import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';
import { ProdavnicaService } from './services/prodavnica.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'prodavnicakva';
  korpaCounter = 0; // Brojač artikala u korpi
  private korpaSubscription: Subscription | null = null; // Inicijalizovano sa null

  constructor(
    public authService: AuthService,
    private router: Router,
    private prodavnicaService: ProdavnicaService // Dodavanje servisa za prodavnicu
  ) {}

  ngOnInit(): void {
    // Pratimo promene u broju artikala u korpi
    this.korpaSubscription = this.prodavnicaService.getKorpaCounterObservable().subscribe(
      (noviBroj: number) => {
        this.korpaCounter = noviBroj; // Ažuriraj brojač na osnovu emitovane vrednosti
      }
    );
  }

  ngOnDestroy(): void {
    if (this.korpaSubscription) {
      this.korpaSubscription.unsubscribe(); // Oslobađanje resursa kad komponenta bude uništena
    }
  }

  // Metoda za logovanje korisnika
  logout(): void {
    this.authService.logout();
  }

  // Navigacija ka profilu korisnika
  idiNaProfil(): void {
    if (this.authService.getTrenutniKorisnik()) {
      this.router.navigate(['/profil']);
    } else {
      alert('Niste ulogovani!');
    }
  }
}
