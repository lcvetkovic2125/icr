import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'; 
import { AppRoutingModule } from './app-routing.module';
import { NgxSliderModule } from '@angular-slider/ngx-slider';

import { AppComponent } from './app.component';
import { PocetnaComponent } from './components/pocetna/pocetna.component';
import { KorpaComponent } from './components/korpa/korpa.component';
import { PlacanjeComponent } from './components/placanje/placanje.component';
import { ProizvodiComponent } from './components/proizvodi/proizvodi.component';
import { RezervacijeComponent } from './components/rezervacije/rezervacije.component';
import { DetaljiProizvodaComponent } from './components/detalji-proizvoda/detalji-proizvoda.component';
import { ProdavnicaService } from './services/prodavnica.service';
import { LoginComponent } from './components/login/login.component';
import { RegistracijaComponent } from './components/registracija/registracija.component';
import { KorisnickiProfilComponent } from './components/korisnicki-profil/korisnicki-profil.component';


@NgModule({
  declarations: [
    AppComponent,
    PocetnaComponent,
    KorpaComponent,
    PlacanjeComponent,
    ProizvodiComponent,
    RezervacijeComponent,
    DetaljiProizvodaComponent,
    LoginComponent,
    RegistracijaComponent,
    KorisnickiProfilComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    NgxSliderModule
  ],
  providers: [ProdavnicaService],
  bootstrap: [AppComponent]
})
export class AppModule { }
