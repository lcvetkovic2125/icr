import { Component } from '@angular/core';

@Component({
  selector: 'app-placanje',
  templateUrl: './placanje.component.html',
  styleUrls: ['./placanje.component.css']
})
export class PlacanjeComponent {
  nazivProizvoda: string = 'Proizvod XYZ'; // Primer naziva proizvoda
  cenaProizvoda: number = 1000; // Primer cene proizvoda

  placeno: boolean = false;

  plati(): void {
    // Ovde možete dodati logiku za obradu plaćanja, npr. poziv servisa za plaćanje

    // Simulacija uspešnog plaćanja
    this.placeno = true;
  }
}
