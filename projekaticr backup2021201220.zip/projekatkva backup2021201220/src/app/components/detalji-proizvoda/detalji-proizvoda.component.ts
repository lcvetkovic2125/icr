import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProdavnicaService } from '../../services/prodavnica.service';
import { AuthService } from '../../services/auth.service';
import { Artikal } from '../../services/prodavnica.service';

@Component({
  selector: 'app-detalji-proizvoda',
  templateUrl: './detalji-proizvoda.component.html',
  styleUrls: ['./detalji-proizvoda.component.css']
})
export class DetaljiProizvodaComponent implements OnInit {
  proizvod: Artikal | undefined; // Detalji o proizvodu
  ocene: number[] = []; // Lista ocena za proizvod
  novaOcena: number = 0; // Nova ocena koju korisnik želi da ostavi
  prosecnaOcena: number = 0; // Prosečna ocena za proizvod
  trenutniKorisnik: string | null = null; // Ime trenutno ulogovanog korisnika

  constructor(
    private route: ActivatedRoute,
    private prodavnicaService: ProdavnicaService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.proizvod = this.prodavnicaService.getProizvodById(id); // Dohvatanje proizvoda putem servisa

    // Dohvatanje trenutno ulogovanog korisnika
    const korisnik = this.authService.getTrenutniKorisnik();
    this.trenutniKorisnik = korisnik ? korisnik.ime : null;

    // Učitavanje postojećih ocena
    if (this.proizvod) {
      this.ocene = this.prodavnicaService.getOceneByProizvodId(this.proizvod.id);
      this.izracunajProsecnuOcenu();
    }
  }

  // Ažuriranje prosečne ocene
  izracunajProsecnuOcenu(): void {
    const zbir = this.ocene.reduce((a, b) => a + b, 0);
    this.prosecnaOcena = this.ocene.length > 0 ? parseFloat((zbir / this.ocene.length).toFixed(2)) : 0;
  }

  // Postavljanje ocene klikom na zvezdicu
  setOcenu(ocena: number) {
    this.novaOcena = ocena; // Postavljanje ocene prema kliknutoj zvezdici
  }

  // Dodavanje nove ocene
  dodajOcenu(): void {
    if (this.novaOcena >= 1 && this.novaOcena <= 5) {
      if (this.proizvod && this.trenutniKorisnik) {
        this.prodavnicaService.dodajOcenu(this.proizvod.id, this.novaOcena);
        this.ocene.push(this.novaOcena);
        this.izracunajProsecnuOcenu();
        this.novaOcena = 0; // Resetovanje unosa ocene
      } else {
        alert('Morate biti ulogovani da biste dodali ocenu.');
      }
    } else {
      alert('Ocena mora biti između 1 i 5.');
    }
  }

  // Dodavanje proizvoda u korpu
  dodajUKorpu(proizvod: Artikal): void {
    if (!this.authService.getTrenutniKorisnik()) {
      alert('Morate da se ulogujete da bi ubacili artikl u korpu!');
      return;
    }
    console.log('Dodavanje u korpu', proizvod);
    this.prodavnicaService.dodajUKorpu(proizvod);
    alert('Proizvod je uspešno dodat u korpu!');
  }
}