import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProizvodiComponent } from './proizvodi.component';
import { ProdavnicaService, Artikal } from '../../services/prodavnica.service';

describe('ProizvodiComponent', () => {
  let component: ProizvodiComponent;
  let fixture: ComponentFixture<ProizvodiComponent>;
  let prodavnicaService: ProdavnicaService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ProizvodiComponent],
      providers: [ProdavnicaService]
    });

    fixture = TestBed.createComponent(ProizvodiComponent);
    component = fixture.componentInstance;
    prodavnicaService = TestBed.inject(ProdavnicaService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add items to the cart', () => {
    const artikal1 = { id: 1, naziv: 'Majica', cena: 1299, starost: 'M', boja: 'Crvena', slika: 'assets/majica1.jpg', opis: 'majica' };
    component.dodajUKorpu(artikal1);
    expect(prodavnicaService.korpa.artikli.length).toBe(1);
    expect(prodavnicaService.korpa.artikli[0]).toEqual(artikal1);
  });

  it('should calculate the total price correctly', () => {
    const artikal1 = { id: 1, naziv: 'Majica', cena: 1299, starost: 'M', boja: 'Crvena', slika: 'assets/majica1.jpg', opis: 'majica' };
    const artikal2 = { id: 2, naziv: 'Pantalone', cena: 1999, starost: 'L', boja: 'Plava', slika: 'assets/pantalone2.jpg', opis: 'pantalone' };
    component.dodajUKorpu(artikal1);
    component.dodajUKorpu(artikal2);
    expect(prodavnicaService.izracunajUkupno()).toBe(3298);
  });
});
