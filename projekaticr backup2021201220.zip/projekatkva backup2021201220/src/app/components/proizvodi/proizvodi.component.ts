import { Component } from '@angular/core';
import { Options } from '@angular-slider/ngx-slider';
import { ProdavnicaService, Artikal } from '../../services/prodavnica.service';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-proizvodi',
  templateUrl: './proizvodi.component.html',
  styleUrls: ['./proizvodi.component.css']
})
export class ProizvodiComponent {
  proizvodi: Artikal[] = [];
  filtriraniProizvodi: Artikal[] = [];
  minCena: number = 0;
  maxCena: number = 2099;
  options: Options = {
    floor: 0,
    ceil: 2099
  };

  selectedStarost: string = 'sve';
  selectedBoja: string = 'sve';
  searchText: string = '';
  korpaCounter: number = 0; // Dodavanje brojača za proizvode u korpi

  constructor(private prodavnicaService: ProdavnicaService, private authService: AuthService, private router: Router) {
    this.proizvodi = this.prodavnicaService.getProizvodi(); // Dobijanje liste proizvoda iz servisa
    this.filtriraniProizvodi = [...this.proizvodi]; // Kopija proizvoda za filtriranje
  }

  dodajUKorpu(proizvod: Artikal): void {
    if (!this.authService.getTrenutniKorisnik()) {
      alert('Morate da se ulogujete da bi ubacili artikl u korpu!');
      return;
    }
    console.log('Dodavanje u korpu', proizvod);
    this.prodavnicaService.dodajUKorpu(proizvod);
    this.korpaCounter++; // Povećavanje brojača kada proizvod bude dodat u korpu
    alert('Proizvod je uspešno dodat u korpu!');
  }

  pretraziProizvode(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.searchText = target?.value.toLowerCase() || '';
    this.applyFilters();
  }

  filtrirajPoVelicini(event: Event): void {
    const target = event.target as HTMLSelectElement;
    this.selectedStarost = target?.value || 'sve';
    this.applyFilters();
  }

  filtrirajPoBoji(event: Event): void {
    const target = event.target as HTMLSelectElement;
    this.selectedBoja = target?.value || 'sve';
    this.applyFilters();
  }

  sortirajPoCeni(event: Event): void {
    const target = event.target as HTMLSelectElement;
    const sortType = target?.value;

    if (sortType === 'low-to-high') {
      this.filtriraniProizvodi.sort((a, b) => a.cena - b.cena);
    } else if (sortType === 'high-to-low') {
      this.filtriraniProizvodi.sort((a, b) => b.cena - a.cena);
    }
  }

  filtrirajPoCeni(): void {
    this.filtriraniProizvodi = this.proizvodi.filter(proizvod =>
      proizvod.cena >= this.minCena && proizvod.cena <= this.maxCena
    );
  }

  naPromenuCene(minCena: number, maxCena: number): void {
    this.minCena = minCena;
    this.maxCena = maxCena;
    this.filtrirajPoCeni();
  }

  private applyFilters(): void {
    this.filtriraniProizvodi = this.proizvodi.filter(proizvod => {
      return (
        (this.selectedStarost === 'sve' || proizvod.starost === this.selectedStarost) &&
        (this.selectedBoja === 'sve' || proizvod.boja === this.selectedBoja) &&
        proizvod.naziv.toLowerCase().includes(this.searchText) &&
        proizvod.cena >= this.minCena && proizvod.cena <= this.maxCena
      );
    });
  }

  otvoriDetalje(proizvodId: number): void {
    this.router.navigate(['/detalji-proizvoda', proizvodId]);
  }
}
