import { ComponentFixture, TestBed } from '@angular/core/testing';
import { KorpaComponent } from './korpa.component';
import { ProdavnicaService } from '../../services/prodavnica.service';

describe('KorpaComponent', () => {
  let component: KorpaComponent;
  let fixture: ComponentFixture<KorpaComponent>;
  let prodavnicaService: ProdavnicaService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [KorpaComponent],
      providers: [ProdavnicaService]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KorpaComponent);
    component = fixture.componentInstance;
    prodavnicaService = TestBed.inject(ProdavnicaService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add items to the cart', () => {
    const artikal = { id: 1, naziv: 'Majica', cena: 1299, starost: 'M', boja: 'Crvena', slika: 'assets/majica1.jpg' };
    prodavnicaService.dodajUKorpu(artikal);
    expect(prodavnicaService.korpa.artikli.length).toBe(1);
    expect(prodavnicaService.korpa.artikli[0]).toEqual(artikal);
  });

  it('should remove items from the cart', () => {
    const artikal = { id: 1, naziv: 'Majica', cena: 1299, starost: 'M', boja: 'Crvena', slika: 'assets/majica1.jpg' };
    prodavnicaService.dodajUKorpu(artikal);
    component.ukloniIzKorpe(artikal.id);
    expect(prodavnicaService.korpa.artikli.length).toBe(0);
  });

  it('should calculate the total price correctly', () => {
    const artikal1 = { id: 1, naziv: 'Majica', cena: 1299, starost: 'M', boja: 'Crvena', slika: 'assets/majica1.jpg' };
    const artikal2 = { id: 2, naziv: 'Pantalone', cena: 1999, starost: 'L', boja: 'Plava', slika: 'assets/pantalone2.jpg' };
    prodavnicaService.dodajUKorpu(artikal1);
    prodavnicaService.dodajUKorpu(artikal2);
    expect(prodavnicaService.izracunajUkupno()).toBe(3298);
  });
});
