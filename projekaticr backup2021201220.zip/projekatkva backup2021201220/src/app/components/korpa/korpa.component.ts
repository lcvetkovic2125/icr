import { Component, OnInit } from '@angular/core';
import { ProdavnicaService, Artikal } from '../../services/prodavnica.service';

@Component({
  selector: 'app-korpa',
  templateUrl: './korpa.component.html',
  styleUrls: ['./korpa.component.css']
})
export class KorpaComponent implements OnInit {
  artikli: Artikal[] = [];
  filtriraniArtikli: Artikal[] = [];
  ukupno: number = 0;
  searchText: string = ''; // Za pretragu

  // Lokalna promenljiva koja čuva status artikala
  artikliSaStatusom: { artikal: Artikal, status: string }[] = [];

  constructor(public prodavnicaService: ProdavnicaService) {}

  ngOnInit(): void {
    this.artikli = this.prodavnicaService.getArtikli();
    this.filtriraniArtikli = [...this.artikli]; // Početno postavljanje filtriranih artikala
    this.ukupno = this.prodavnicaService.izracunajUkupno();
  }

  ukloniIzKorpe(id: number): void {
    this.prodavnicaService.ukloniIzKorpe(id);
    this.artikli = this.prodavnicaService.getArtikli();
    this.artikliSaStatusom = this.artikliSaStatusom.filter(item => item.artikal.id !== id);  
    this.ukupno = this.prodavnicaService.izracunajUkupno();
    this.applySearchFilter(); // Ponovno primenjujemo filter pretrage
  }

  zavrsiKupovinu(): void {
    alert('Kupovina završena!');
  }

  updateStatus(artikal: Artikal, noviStatus: string): void {
    console.log(`Ažuriranje statusa za artikal: ${artikal.naziv}, novi status: ${noviStatus}`);
    this.prodavnicaService.updateStatus(artikal.id, noviStatus);
    
    const item = this.artikli.find(a => a.id === artikal.id);
    if (item) {
      item.status = noviStatus;
    }
    
    this.ukupno = this.prodavnicaService.izracunajUkupno();
  }

  // Funkcija za pretragu artikala
  pretraziArtikle(event: Event): void {
    const target = event.target as HTMLInputElement;
    this.searchText = target?.value.toLowerCase() || '';
    this.applySearchFilter(); // Primeni filter pretrage
  }

  private applySearchFilter(): void {
    this.filtriraniArtikli = this.artikli.filter(artikal => 
      artikal.naziv.toLowerCase().includes(this.searchText)
    );
  }
}
