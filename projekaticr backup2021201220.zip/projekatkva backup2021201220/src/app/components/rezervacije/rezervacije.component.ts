import { Component } from '@angular/core';

@Component({
  selector: 'app-rezervacije',
  templateUrl: './rezervacije.component.html',
  styleUrls: ['./rezervacije.component.css'] // Ovo je ispravljeno, prethodno je bilo "styleUrl"
})
export class RezervacijeComponent {
  // Dodajte potrebne metode i polja ovde ako su potrebni
}
