import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router } from '@angular/router';

interface Korisnik {
  id: number;
  ime: string;
  prezime: string;
  email: string;
  telefon: string;
  adresa: string;
  username: string;
  password: string;
}

@Component({
  selector: 'app-korisnicki-profil',
  templateUrl: './korisnicki-profil.component.html',
  styleUrls: ['./korisnicki-profil.component.css']
})
export class KorisnickiProfilComponent {
  korisnik: Korisnik;

  constructor(private authService: AuthService, private router: Router) {
    const trenutniKorisnik = this.authService.getTrenutniKorisnik();
    if (trenutniKorisnik) {
      this.korisnik = { ...trenutniKorisnik };
    } else {
      this.korisnik = { id: 0, ime: '', prezime: '', email: '', telefon: '', adresa: '', username: '', password: '' };
    }
  }

  sacuvaj(): void {
    this.authService.updateKorisnik(this.korisnik);
    alert('Podaci su uspešno sačuvani!');
    this.authService.setTrenutniKorisnik(this.korisnik); // Update the current user in AuthService
    this.router.navigate(['/pocetna']); // Redirect to home page
  }
}
