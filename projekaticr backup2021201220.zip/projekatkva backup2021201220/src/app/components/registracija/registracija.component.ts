import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-registracija',
  templateUrl: './registracija.component.html',
  styleUrls: ['./registracija.component.css']
})
export class RegistracijaComponent {
  ime: string = '';
  prezime: string = '';
  email: string = '';
  telefon: string = '';
  adresa: string = '';
  username: string = '';
  password: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  registracija(): void {
    if (this.authService.registracija({
      id: 0,
      ime: this.ime,
      prezime: this.prezime,
      email: this.email,
      telefon: this.telefon,
      adresa: this.adresa,
      username: this.username,
      password: this.password
    })) {
      alert('Registracija uspešna');
    } else {
      alert('Korisničko ime već postoji');
    }
  }
}
