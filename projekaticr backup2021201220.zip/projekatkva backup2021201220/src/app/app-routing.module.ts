import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PocetnaComponent } from './components/pocetna/pocetna.component';
import { KorpaComponent } from './components/korpa/korpa.component';
import { PlacanjeComponent } from './components/placanje/placanje.component';
import { ProizvodiComponent } from './components/proizvodi/proizvodi.component';
import { DetaljiProizvodaComponent } from './components/detalji-proizvoda/detalji-proizvoda.component';
import { RezervacijeComponent } from './components/rezervacije/rezervacije.component';
import { RegistracijaComponent } from './components/registracija/registracija.component';
import { LoginComponent } from './components/login/login.component';
import { KorisnickiProfilComponent } from './components/korisnicki-profil/korisnicki-profil.component';




const routes: Routes = [
  { path: '', component: PocetnaComponent },
  { path: 'korpa', component: KorpaComponent },
  { path: 'placanje', component: PlacanjeComponent },
  { path: 'proizvodi', component: ProizvodiComponent },
  { path: 'detalji-proizvoda/:id', component: DetaljiProizvodaComponent },
  { path: 'rezervacije', component: RezervacijeComponent },
  { path: 'registracija', component: RegistracijaComponent },
  { path: 'login', component: LoginComponent },
  { path: 'profil', component: KorisnickiProfilComponent },
  { path: '', component: PocetnaComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
