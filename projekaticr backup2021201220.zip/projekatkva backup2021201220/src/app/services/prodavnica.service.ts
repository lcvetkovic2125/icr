import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { AuthService } from './auth.service';

// Definisanje klase Artikal
export class Artikal {
  constructor(
    public id: number,
    public naziv: string,
    public cena: number,
    public starost: string,
    public boja: string,
    public slika: string,
    public opis: string,
    public status: string = 'u toku', // Dodajemo status sa početnim vrednostima
    public ocene: number[] = []
  ) {}
}

// Klasa Korpa koja čuva artikle
class Korpa {
  artikli: Artikal[] = [];

  dodajArtikal(artikal: Artikal): void {
    this.artikli.push(artikal);
    console.log('Artikal dodat u korpu:', artikal);
  }

  ukloniArtikal(id: number): void {
    this.artikli = this.artikli.filter((artikal) => artikal.id !== id);
  }

  izracunajUkupno(): number {
    return this.artikli.reduce((ukupno, artikal) => ukupno + artikal.cena, 0);
  }

  getBrojArtikala(): number {
    return this.artikli.length; // Broj proizvoda u korpi
  }

  // Metoda za promenu statusa porudžbine
  updateStatus(id: number, status: string): void {
    const artikal = this.artikli.find((a) => a.id === id);
    if (artikal) {
      artikal.status = status;
    }
  }
}

@Injectable({
  providedIn: 'root',
})
export class ProdavnicaService {
  private korpe: { [korisnikId: number]: Korpa } = {};
  private proizvodi: Artikal[] = [
    new Artikal(1, 'Bengalska mačka - Miljana🐈', 1500, '6', 'Zuta', 'assets/1.jpg', 'Miljana je divlja i energična mačka, poznata po svojoj lepoti i neustrašivosti. Njena krznena boja podseća na divlje tigrove.'),
    new Artikal(2, 'Ruska plava mačka - Sofi🐈', 800, '24', 'Siva', 'assets/2.jpeg', 'Sofi je dostojanstvena mačka, sa zelenim očima i njenim sivim krznom odražava njenu plemenitu prirodu.'),
    new Artikal(3, 'Ragdoll mačka - Bella🐈', 1200, '12', 'Bela', 'assets/3.jpg', 'Bella je nežna mačka koja je poznata po tome što se opušta u naručju svog vlasnika. Lepe plave oči čine je pravim draguljem.'),
    new Artikal(4, 'Chausie mačka - Hunter🐈', 2000, '24', 'Zuta', 'assets/4.jpg', 'Hunter je energična mačka, poznata po svom agilnom i istraživačkom karakteru. Njeno divlje poreklo čini je snažnom i hrabrom.'),
    new Artikal(5, 'Sibirska mačka - Mika🐈', 1000, '12', 'Bela', 'assets/5.jpg', 'Mika je hrabra mačka sa debelim krznom koje je štiti od hladnoće. Njena priroda i ljubav prema igri čine je odličnim izborom.'),
    new Artikal(6, 'Američka kratkodlaka mačka - Leo🐈', 700, '6', 'Sarena', 'assets/6.jpg', 'Leo je brz i razigran mačak koji je poznat po svom kratkom krznu i energičnoj prirodi.'),
    new Artikal(7, 'Britanska kratkodlaka mačka - Lili🐈', 900, '18', 'Siva', 'assets/7.jpg', 'Lili je mačka sa krznom koje podseća na pliš, nežna je i staložena, idealna za mirne domove.'),
    new Artikal(8, 'Birmanska mačka - Meče🐈', 1100, '18', 'Bela', 'assets/8.jpg', 'Meče je poznat po svojoj lepoj svetloj boji i dubokim očima. Iako povučen, obožava da se mazi i uvek je veran svom domu.'),
    new Artikal(9, 'Bobtail mačka - Max🐈', 500, '12', 'Sarena', 'assets/9.jpg', 'Max je radoznao mačak sa prepoznatljivim kratkim repom. Njegova energičnost i entuzijazam donose radost svakom domu.'),
    new Artikal(10, 'Norveška šumska mačka - Elza🐈', 1900, '6', 'Sarena', 'assets/10.jpg', 'Elza je mačka koja ima nezavisnu prirodu i ljubav prema istraživanju što je čini odličnim ljubimcem za avanturiste.'),
    new Artikal(11, 'Persijska mačka - Kleo🐈', 850, '12', 'Bela', 'assets/11.jpg', 'Kleo je mačka sa dugim, svilenkastim krznom i nevino plavim očima. Njena elegancija i mirna priroda čine je idealnim ljubimcem.'),
    new Artikal(12, 'Sijamska mačka - Mia🐈', 600, '18', 'Sarena', 'assets/12.jpg', 'Mia je mačka sa očima koje se sijaju kao dragulj. Njena glasna i vesela priroda je zaražujuća, uživa u društvu sa svojim vlasnicima.'),
  ];

  // BehaviorSubject za brojač artikala
  private korpaCounterSubject = new BehaviorSubject<number>(0);

  constructor(private authService: AuthService) {
    this.ucitajKorpa();
  }

  // Dobijanje trenutne korpe korisnika
  private getTrenutnaKorpa(): Korpa {
    const korisnikId = this.authService.getTrenutniKorisnikId();
    if (korisnikId === null) {
      throw new Error('Nema ulogovanog korisnika.');
    }

    if (!this.korpe[korisnikId]) {
      this.korpe[korisnikId] = new Korpa();
    }

    return this.korpe[korisnikId];
  }

  // Dodavanje artikla u korpu
  dodajUKorpu(artikal: Artikal): void {
    const korpa = this.getTrenutnaKorpa();
    korpa.dodajArtikal(artikal);
    this.korpaCounterSubject.next(korpa.getBrojArtikala()); // Ažuriranje brojača
    this.saveKorpa();
  }

  ukloniIzKorpe(id: number): void {
    const korpa = this.getTrenutnaKorpa();
    
    // Reset statusa artikla pre uklanjanja
    const artikal = korpa.artikli.find((artikal) => artikal.id === id);
    if (artikal) {
      artikal.status = 'u toku';
    }
  
    korpa.ukloniArtikal(id);
    this.korpaCounterSubject.next(korpa.getBrojArtikala()); // Ažuriranje brojača
    this.saveKorpa();
  }
  

// Izračunavanje ukupne cene u korpi
izracunajUkupno(): number {
  const korpa = this.getTrenutnaKorpa();
  // Filtriraj artikle koji nisu odbijeni
  return korpa.artikli
    .filter((artikal) => artikal.status !== 'odbijena') // Ne uključuj odbijene artikle
    .reduce((ukupno, artikal) => ukupno + artikal.cena, 0); // Sumarno dodavanje cena
}


  // Dohvatanje artikala u trenutnoj korpi
  getArtikli(): Artikal[] {
    const korpa = this.getTrenutnaKorpa();
    return korpa.artikli;
  }

// Promena statusa porudžbine
updateStatus(id: number, status: string): void {
  const korpa = this.getTrenutnaKorpa();
  const artikal = korpa.artikli.find((a) => a.id === id);
  
  if (artikal) {
    // Ako je artikal označen kao odbijen, oduzmemo njegovu cenu
    if (status === 'odbijena' && artikal.status !== 'odbijena') {
      this.korpaCounterSubject.next(korpa.getBrojArtikala() - 1); // Ažuriraj broj artikala u korpi
    }
    
    artikal.status = status; // Promeni status artikla
  }
  this.saveKorpa();
}


  // Čuvanje korpe u localStorage
  private saveKorpa(): void {
    const korisnikId = this.authService.getTrenutniKorisnikId();
    if (korisnikId !== null) {
      localStorage.setItem(`korpa_${korisnikId}`, JSON.stringify(this.korpe[korisnikId].artikli));
    }
  }

  // Učitavanje korpe iz localStorage
  private ucitajKorpa(): void {
    const korisnikId = this.authService.getTrenutniKorisnikId();
    if (korisnikId !== null) {
      const artikli = localStorage.getItem(`korpa_${korisnikId}`);
      if (artikli) {
        this.korpe[korisnikId] = new Korpa();
        this.korpe[korisnikId].artikli = JSON.parse(artikli);
        this.korpaCounterSubject.next(this.korpe[korisnikId].getBrojArtikala()); // Postavi brojač
      }
    }
  }

  // Dohvatanje svih proizvoda
  getProizvodi(): Artikal[] {
    return this.proizvodi;
  }

  // Dohvatanje proizvoda po ID-u
  getProizvodById(id: number): Artikal | undefined {
    return this.proizvodi.find((p) => p.id === id);
  }

  // Observable za brojač artikala
  getKorpaCounterObservable() {
    return this.korpaCounterSubject.asObservable();
  }

  // Dodavanje ocene za proizvod
dodajOcenu(proizvodId: number, ocena: number): void {
  const proizvod = this.getProizvodById(proizvodId);
  if (proizvod) {
    proizvod.ocene.push(ocena); // Dodaj ocenu u listu
  }
}

// Izračunavanje prosečne ocene proizvoda
getProsecnaOcena(proizvodId: number): number {
  const proizvod = this.getProizvodById(proizvodId);
  if (proizvod && proizvod.ocene.length > 0) {
    const ukupno = proizvod.ocene.reduce((sum, ocena) => sum + ocena, 0);
    return ukupno / proizvod.ocene.length;
  }
  return 0; // Ako nema ocena, vrati 0
}

getOceneByProizvodId(proizvodId: number): number[] {
  const proizvod = this.getProizvodById(proizvodId);
  return proizvod ? proizvod.ocene : [];
}

}
