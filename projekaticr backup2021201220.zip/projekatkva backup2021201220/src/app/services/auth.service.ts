import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

interface Korisnik {
  id: number;
  ime: string;
  prezime: string;
  email: string;
  telefon: string;
  adresa: string;
  username: string;
  password: string;
}

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private korisnici: Korisnik[] = [];
  private trenutniKorisnik: Korisnik | null = null;

  constructor(private router: Router) {
    this.ucitajKorisnike();
    this.ucitajTrenutnogKorisnika();
  }

  registracija(korisnik: Korisnik): boolean {
    if (this.korisnici.find(k => k.username === korisnik.username)) {
      return false; // Korisničko ime već postoji
    }
    korisnik.id = this.korisnici.length + 1;
    this.korisnici.push(korisnik);
    this.trenutniKorisnik = korisnik;
    this.saveKorisnici();
    this.saveTrenutniKorisnik();
    this.router.navigate(['/']);
    return true;
  }

  login(username: string, password: string): boolean {
    const korisnik = this.korisnici.find(k => k.username === username && k.password === password);
    if (korisnik) {
      this.trenutniKorisnik = korisnik;
      this.saveTrenutniKorisnik();
      this.router.navigate(['/']);
      return true;
    }
    return false;
  }

  logout(): void {
    this.trenutniKorisnik = null;
    localStorage.removeItem('trenutniKorisnik');
    this.router.navigate(['/login']);
  }

  getTrenutniKorisnik(): Korisnik | null {
    if (!this.trenutniKorisnik) {
      const korisnik = localStorage.getItem('trenutniKorisnik');
      if (korisnik) {
        this.trenutniKorisnik = JSON.parse(korisnik);
      }
    }
    return this.trenutniKorisnik;
  }

  getTrenutniKorisnikId(): number | null {
    const korisnik = this.getTrenutniKorisnik();
    return korisnik ? korisnik.id : null;
  }

  private ucitajKorisnike(): void {
    const korisnici = localStorage.getItem('korisnici');
    if (korisnici) {
      this.korisnici = JSON.parse(korisnici);
    }
  }

  private saveKorisnici(): void {
    localStorage.setItem('korisnici', JSON.stringify(this.korisnici));
  }

  private ucitajTrenutnogKorisnika(): void {
    const korisnik = localStorage.getItem('trenutniKorisnik');
    if (korisnik) {
      this.trenutniKorisnik = JSON.parse(korisnik);
    }
  }

  private saveTrenutniKorisnik(): void {
    if (this.trenutniKorisnik) {
      localStorage.setItem('trenutniKorisnik', JSON.stringify(this.trenutniKorisnik));
    }
  }

  updateKorisnik(korisnik: Korisnik): void {
    const index = this.korisnici.findIndex(k => k.id === korisnik.id);
    if (index !== -1) {
      this.korisnici[index] = korisnik;
      this.saveKorisnici();
      this.setTrenutniKorisnik(korisnik);
    }
  }

  setTrenutniKorisnik(korisnik: Korisnik): void {
    this.trenutniKorisnik = korisnik;
    this.saveTrenutniKorisnik();
  }
}
